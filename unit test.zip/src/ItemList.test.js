

import React from 'react';
import { render, fireEvent, screen,} from '@testing-library/react';
import ItemList from './ItemList'; //  component is in a separate file

     // ------test case 1--------

    test('renders the item list and allows adding, editing, and deleting items', () => {
    // Render the component
    render(<ItemList />);

    // Add an item
    const idInput = screen.getByPlaceholderText('id');
    const nameInput = screen.getByPlaceholderText('name');
    const emailInput = screen.getByPlaceholderText('gmail');
    const maleRadioButton = screen.getByLabelText('Male');
    const addButton = screen.getByText('Add');

    fireEvent.change(idInput, { target: { value: '1' } });
    fireEvent.change(nameInput, { target: { value: 'shubh' } });
    fireEvent.change(emailInput, { target: { value: 'chaudharishubh000@gmail.com' } });
    fireEvent.click(maleRadioButton);
    fireEvent.click(addButton);

    //  item is added

    expect(screen.getByText('1')).toBeInTheDocument();
    expect(screen.getByText('shubh')).toBeInTheDocument();
    expect(screen.getByText('chaudharishubh000@gmail.com')).toBeInTheDocument();

});



    // --------unit test case  no 2---------

    // Delete the item
    test("delete  item unit test case 2", () => {
    // render component
    render(<ItemList />)
    const deleteButton = screen.getByText('Delete');
    fireEvent.click(deleteButton);
    expect(screen.queryByText('shubhhhh')).not.toBeInTheDocument();

})

    // ---------unit case  no 3 ------

    test("edit  item  unit test case 3", () => {
    render(<ItemList />)

    // Edit the item
    const editButton = screen.getByText('Edit');
    fireEvent.click(editButton);
    const newNameInput = screen.getByPlaceholderText('name');
    fireEvent.change(newNameInput, { target: { value: 'shubh chaudhari' } });
    expect(newNameInput.value).toBe('shubh chaudhari')
})
