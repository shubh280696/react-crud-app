
import './App.css';
import 'bootstrap/dist/css/bootstrap.min.css';

import ItemList from './ItemList';

function App() {
  return (
    <div className="App">
      <p> learn react unit testing</p>
      <ItemList />
    </div>
  );
}

export default App;
